import streamlit as st
import pandas as pd 
import matplotlib.pyplot as plt

# Configure the Streamlit page settings
st.set_page_config(
page_title="Explore",   
page_icon="chart",       
layout="wide", 
)

# Display the main dashboard title
st.title('dashboard')


# # Load and prepare all datasets used in the dashboard.

df = pd.read_csv('data/account-statement-1-1-2024-12-31-2024.csv', sep=';')
df.columns = df.columns.str.strip() # clean column names
df = df.drop(columns=["Unnamed: 5"])  #remove unnecessary column.



df_2 = pd.read_csv('data/symbols.csv',sep=';')
df_2.columns = df_2.columns.str.strip()


# Convert the Date column to a datetime format (DD/MM/YYYY) ---> for this reason there is dayfirst = True
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True)

# Remove missing values
df = df.dropna(subset=["Date"])

# Convert dataframe dates to date-only (to match Streamlit input type)
df["Date_only"] = df["Date"].dt.date

# Set up start_date and end_date 
start_date, end_date = st.date_input(
    "Date range",
    value=(
        pd.to_datetime("2024-01-01").date(),
        pd.to_datetime("2024-12-31").date()
    )
)

# Filter dataset based on selected date range
df = df[
    (df["Date_only"] >= start_date) &
    (df["Date_only"] <= end_date)
]


# Utility functions for chart customization:
# - clean_spines() removes the top and right borders for a cleaner look.
# - annotate_hbar() adds value labels to horizontal bar charts.

def clean_spines(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    return ax

def annotate_hbar(ax, fmt="{:.1f}"):
    for patch in ax.patches:
        width = patch.get_width()
        y = patch.get_y() + patch.get_height() / 2
        ax.text(width, y, "  " + fmt.format(width), va="center", fontsize=12)


#CHARTS

# 1.  A line chart showing total number of transactions (BUY + SELL) over time.

daily = df.groupby("Date")["IDTransaction"].count().reset_index()  #count the number of transactions for each Date.
daily.columns = ["Date", "Transaction Count"]
st.title("Transactions over time")
st.line_chart(daily, x="Date", y="Transaction Count",height=400)


# 2. A bar chart showing the top 3 traded symbols by transaction count.

top_symbol = (
    df.groupby("Symbol")["IDTransaction"] #count the number of transactions for each symbol.
    .count()
    .reset_index()
    .sort_values(by="IDTransaction", ascending=False)  #sort the results in descending order.
    .head(3)  #select the top three.
)

fig, ax = plt.subplots(figsize=(12,5))

ax.barh(top_symbol["Symbol"],
    top_symbol["IDTransaction"],
    color = "#E45756"
    )

fig.suptitle("Top 3 Traded Symbols",
        fontsize=16,
        fontweight="bold",
        y=1.03
    )

ax.set_xlabel("Transaction Count")
ax.set_ylabel("Symbols")
ax.grid(axis="x", alpha=0.25)
clean_spines(ax)
annotate_hbar(ax, fmt="{:.0f}")

st.pyplot(fig)


 # 3. A bar chart showing the top 5 sectors by transaction count

 #Merge the transaction dataset (df) with the symbols dataset (df_2),
 #since IDTransaction is stored in df while sector and industry information are stored in df_2. 
 # The two datasets are linked through a common key:'Symbol' in df and 'symbol' in df_2.

df_merged = df.merge(df_2, left_on="Symbol", right_on="symbol", how="left")


top_sector = (
    df_merged.groupby("sector")["IDTransaction"] #count the number of transactions for each sector.
    .count()
    .reset_index()
    .sort_values(by="IDTransaction", ascending=False)  #sort the results in descending order.
    .head(5)  #select the top five sectors.
)

fig, ax = plt.subplots()

ax.barh(top_sector["sector"],
    top_sector["IDTransaction"],
    color = "lightblue",
)


fig.suptitle("Top 5 Traded Sectors by Transaction Count",
        fontsize=16,
        fontweight="bold",
        y=1.03
    )

ax.set_xlabel("Transaction Count")
ax.set_ylabel("Sectors")
ax.grid(axis="x", alpha=0.25)
clean_spines(ax)
annotate_hbar(ax, fmt="{:.0f}")

st.pyplot(fig)

# 4. A bar chart showing the top 5 industries by transaction count

top_industries = (
    df_merged.groupby("industry")["IDTransaction"] #count the number of transactions for each industry. 
    .count()
    .reset_index()
    .sort_values(by="IDTransaction", ascending=False)   #sort the results in descending order.
    .head(5) #select the top five industries. 
)

fig, ax = plt.subplots()

ax.barh(top_industries["industry"],
    top_industries["IDTransaction"],
    color = "#B39DDB"
)


fig.suptitle("Top 5 Traded Industries by Transaction Count",
        fontsize=16,
        fontweight="bold",
        y=1.03
    )

ax.set_xlabel("Transaction Count")
ax.set_ylabel("Industries")
ax.grid(axis="x", alpha=0.25)
clean_spines(ax)
annotate_hbar(ax, fmt="{:.0f}")

st.pyplot(fig)



